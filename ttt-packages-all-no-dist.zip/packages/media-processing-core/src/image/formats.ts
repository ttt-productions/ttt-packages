// shared image format / quality presets
