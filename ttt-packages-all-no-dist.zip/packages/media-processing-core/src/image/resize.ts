// sharp resize helpers extracted from existing image-processor
// intentionally empty until extraction step
